-- Enumerators
TweenDirection_NONE = "NONE"
TweenDirection_LEFT = "LEFT"
TweenDirection_RIGHT = "RIGHT"
TweenDirection_UP = "UP"
TweenDirection_DOWN = "DOWN"